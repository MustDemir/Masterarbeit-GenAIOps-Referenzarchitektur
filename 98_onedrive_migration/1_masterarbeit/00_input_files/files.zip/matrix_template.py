# Matrix Template Reference
# Dieses Script wird von Claude gelesen und als Vorlage verwendet,
# um die Excel-Vergleichsmatrix zu generieren/aktualisieren.
# Claude passt die Daten dynamisch an das jeweilige Paper an.

"""
VERWENDUNG:
- Claude liest dieses Template
- Ersetzt die Platzhalter-Daten mit den tatsächlichen Paper-Daten
- Führt das angepasste Script aus
- Output: /mnt/user-data/outputs/Related_Work_Vergleichsmatrix.xlsx

FARBSCHEMA (fest):
- Header: #1F4E79 (dunkelblau), weiße Schrift
- Kategorien: #E2EFDA (hellgrün), dunkelgrüne Schrift
- ✓ Vollständig: #C6EFCE Hintergrund, #006100 Schrift
- ◐ Teilweise: #FFEB9C Hintergrund, #9C6500 Schrift
- ✗ Nicht adressiert: #FFC7CE Hintergrund, #9C0006 Schrift
- Demir-Spalte: #F0F7FF Hintergrund (Hervorhebung)

STRUKTUR (3 Sheets):
1. Feature-Matrix — Hauptvergleich mit allen Dimensionen
2. Abgrenzungssätze — Zitierfähige Absätze für Kap. 2
3. Lücken-Analyse — PD1/PD2/PD3 Mapping
"""

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ============================================================
# KONFIGURATION — Claude passt diese Werte pro Paper an
# ============================================================

# Demir-Profil (NIEMALS ändern)
DEMIR = {
    "label": "Demir (2026)\n[Eigene Arbeit]",
    "short": "Demir (2026)",
}

# Vergleichs-Papers (Claude fügt hier neue Papers hinzu)
# Format: {"label": "Anzeigename", "short": "Kurzname"}
PAPERS = [
    # Beispiel — Claude ersetzt dies mit den tatsächlichen Papers:
    # {"label": "Mahr et al. (2024)\nIEEE SIITME", "short": "Mahr (2024)"},
    # {"label": "Pourmajidi et al. (2025)\nIEEE TCC", "short": "Pourmajidi (2025)"},
    # {"label": "Buscemi et al. (2025)\narXiv / LIST+RISE", "short": "Buscemi (2025)"},
]

# ============================================================
# DATEN-TEMPLATE — Claude füllt diese Struktur
# ============================================================

# Jeder Eintrag: (dimension, demir_wert, paper1_wert, paper2_wert, ...)
# Reihenfolge der Werte muss mit PAPERS-Liste übereinstimmen
#
# Bewertungs-Präfixe für automatische Farbkodierung:
#   "✓ ..." = Grün (vollständig adressiert)
#   "◐ ..." = Gelb (teilweise adressiert)  
#   "✗"     = Rot (nicht adressiert)
#   Alles andere = Neutral (keine Farbe)

CATEGORIES = [
    ("PUBLIKATION & METHODIK", [
        # (dimension, demir, paper1, paper2, ...)
    ]),
    ("ARCHITEKTUR-SCOPE", []),
    ("QUALITY GATES (USP DEMIR)", []),
    ("COMPLIANCE & REGULATORIK", []),
    ("PIPELINE & TOOLING", []),
    ("GenAI-SPEZIFIKA", []),
    ("GOVERNANCE-STRUKTUR", []),
]

# Abgrenzungssätze: [(paper_short, text, doi), ...]
DELIMITATION_TEXTS = []

# Lücken-Analyse: [(lücke, paper1_status, paper2_status, ..., demir_lösung), ...]
GAPS = []

# ============================================================
# GENERIERUNG — Dieser Teil bleibt unverändert
# ============================================================

def create_matrix():
    wb = Workbook()
    
    HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
    HEADER_FONT = Font(name='Arial', bold=True, color='FFFFFF', size=10)
    SUBHEADER_FILL = PatternFill('solid', fgColor='D6E4F0')
    CATEGORY_FILL = PatternFill('solid', fgColor='E2EFDA')
    CATEGORY_FONT = Font(name='Arial', bold=True, size=9, color='375623')
    YES_FONT = Font(name='Arial', size=9, color='006100')
    YES_FILL = PatternFill('solid', fgColor='C6EFCE')
    NO_FONT = Font(name='Arial', size=9, color='9C0006')
    NO_FILL = PatternFill('solid', fgColor='FFC7CE')
    PARTIAL_FONT = Font(name='Arial', size=9, color='9C6500')
    PARTIAL_FILL = PatternFill('solid', fgColor='FFEB9C')
    CELL_FONT = Font(name='Arial', size=9)
    DEMIR_HIGHLIGHT = PatternFill('solid', fgColor='F0F7FF')
    THIN_BORDER = Border(
        left=Side(style='thin', color='B4C6E7'),
        right=Side(style='thin', color='B4C6E7'),
        top=Side(style='thin', color='B4C6E7'),
        bottom=Side(style='thin', color='B4C6E7')
    )
    
    num_papers = len(PAPERS)
    total_cols = 2 + num_papers  # Dimension + Demir + Papers
    
    # ---- SHEET 1: Feature-Matrix ----
    ws = wb.active
    ws.title = "Feature-Matrix"
    ws.column_dimensions['A'].width = 38
    ws.column_dimensions['B'].width = 28
    for i in range(num_papers):
        ws.column_dimensions[chr(67 + i)].width = 28
    
    # Title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_cols)
    ws['A1'] = 'Related-Work-Vergleichsmatrix — Demir (2026) vs. verwandte Arbeiten'
    ws['A1'].font = Font(name='Arial', bold=True, size=13, color='1F4E79')
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    
    # Headers
    headers = ['Vergleichsdimension', DEMIR["label"]] + [p["label"] for p in PAPERS]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = THIN_BORDER
    ws.row_dimensions[4].height = 40
    
    # Data rows
    row = 5
    for category, items in CATEGORIES:
        if not items:
            continue
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=total_cols)
        cell = ws.cell(row=row, column=1, value=category)
        cell.font = CATEGORY_FONT
        cell.fill = CATEGORY_FILL
        cell.alignment = Alignment(horizontal='left', vertical='center')
        cell.border = THIN_BORDER
        for c in range(2, total_cols + 1):
            ws.cell(row=row, column=c).fill = CATEGORY_FILL
            ws.cell(row=row, column=c).border = THIN_BORDER
        ws.row_dimensions[row].height = 22
        row += 1
        
        for item in items:
            dimension = item[0]
            values = item[1:]  # demir + papers
            all_vals = [dimension] + list(values)
            for col, val in enumerate(all_vals, 1):
                cell = ws.cell(row=row, column=col, value=val)
                cell.font = CELL_FONT
                cell.alignment = Alignment(vertical='center', wrap_text=True)
                cell.border = THIN_BORDER
                if col == 1:
                    cell.font = Font(name='Arial', bold=True, size=9)
                elif col >= 2 and isinstance(val, str):
                    if val.startswith("✓"):
                        cell.font = YES_FONT
                        cell.fill = YES_FILL
                    elif val.startswith("✗"):
                        cell.font = NO_FONT
                        cell.fill = NO_FILL
                    elif val.startswith("◐"):
                        cell.font = PARTIAL_FONT
                        cell.fill = PARTIAL_FILL
            ws.row_dimensions[row].height = 42
            row += 1
    
    # Demir column highlight (column B)
    for r in range(5, row):
        cell = ws.cell(row=r, column=2)
        if not cell.fill or cell.fill.fgColor.rgb in ('00000000', 'FFFFFF'):
            cell.fill = DEMIR_HIGHLIGHT
    
    # Legend
    row += 1
    ws.cell(row=row, column=1, value="Legende:").font = Font(name='Arial', bold=True, size=9)
    row += 1
    for text, fill, font in [
        ("✓ = Vollständig adressiert", YES_FILL, YES_FONT),
        ("◐ = Teilweise / konzeptionell adressiert", PARTIAL_FILL, PARTIAL_FONT),
        ("✗ = Nicht adressiert", NO_FILL, NO_FONT),
    ]:
        cell = ws.cell(row=row, column=1, value=text)
        cell.font = font
        cell.fill = fill
        cell.border = THIN_BORDER
        row += 1
    
    # ---- SHEET 2: Abgrenzungssätze ----
    ws2 = wb.create_sheet("Abgrenzungssätze")
    ws2.column_dimensions['A'].width = 22
    ws2.column_dimensions['B'].width = 90
    ws2.merge_cells('A1:B1')
    ws2['A1'] = 'Zitierfähige Abgrenzungssätze für Kapitel 2'
    ws2['A1'].font = Font(name='Arial', bold=True, size=12, color='1F4E79')
    
    r = 3
    for author, text, doi in DELIMITATION_TEXTS:
        ws2.cell(row=r, column=1, value=author).font = Font(name='Arial', bold=True, size=10, color='1F4E79')
        ws2.cell(row=r, column=1).alignment = Alignment(vertical='top')
        ws2.cell(row=r, column=2, value=text).font = Font(name='Arial', size=10)
        ws2.cell(row=r, column=2).alignment = Alignment(wrap_text=True, vertical='top')
        ws2.row_dimensions[r].height = 85
        if doi:
            r += 1
            ws2.cell(row=r, column=2, value=doi).font = Font(name='Arial', size=9, italic=True, color='4472C4')
        r += 2
    
    # ---- SHEET 3: Lücken-Analyse ----
    ws3 = wb.create_sheet("Lücken-Analyse")
    ws3.column_dimensions['A'].width = 35
    for i in range(num_papers):
        ws3.column_dimensions[chr(66 + i)].width = 20
    ws3.column_dimensions[chr(66 + num_papers)].width = 25
    
    ws3.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2 + num_papers)
    ws3['A1'] = 'Forschungslücken-Analyse: Was adressiert NUR Demir (2026)?'
    ws3['A1'].font = Font(name='Arial', bold=True, size=12, color='1F4E79')
    
    gap_headers = ['Forschungslücke'] + [p["short"] for p in PAPERS] + ['Demir (2026) Lösung']
    for col, h in enumerate(gap_headers, 1):
        cell = ws3.cell(row=3, column=col, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = THIN_BORDER
    
    for i, gap_row in enumerate(GAPS):
        r = 4 + i
        for col, val in enumerate(gap_row, 1):
            cell = ws3.cell(row=r, column=col, value=val)
            cell.font = CELL_FONT
            cell.alignment = Alignment(vertical='center', wrap_text=True)
            cell.border = THIN_BORDER
            if col == 1:
                cell.font = Font(name='Arial', bold=True, size=9)
            elif col == len(gap_row):  # Demir column (last)
                cell.font = YES_FONT
                cell.fill = YES_FILL
            elif val and "Nein" in str(val):
                cell.font = NO_FONT
                cell.fill = NO_FILL
            elif val and ("Teilweise" in str(val) or "Ja" in str(val) or "Konzeptionell" in str(val)):
                cell.font = PARTIAL_FONT
                cell.fill = PARTIAL_FILL
        ws3.row_dimensions[r].height = 42
    
    # Print settings
    for sheet in [ws, ws2, ws3]:
        sheet.page_setup.orientation = 'landscape'
        sheet.page_setup.fitToWidth = 1
    
    output_path = '/mnt/user-data/outputs/Related_Work_Vergleichsmatrix.xlsx'
    wb.save(output_path)
    print(f"Saved to {output_path}")
    return output_path

if __name__ == "__main__":
    create_matrix()
