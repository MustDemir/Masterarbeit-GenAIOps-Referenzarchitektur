---
name: related-work-comparator
description: >
  Systematischer Related-Work-Vergleich für Mustafa Demirs Masterarbeit (Enterprise-Referenzarchitektur für GenAI-Systeme mit Quality Gates und EU AI Act Compliance). Verwende diesen Skill IMMER wenn der User ein Paper (PDF, Text, DOI, oder Zusammenfassung) hochlädt oder einfügt und es mit seiner eigenen Arbeit vergleichen will. Trigger-Phrasen: "vergleich mal", "related work", "wie relevant ist das", "passt das Paper", "Abgrenzung", "bewerte das Paper", "Feature-Matrix", "Vergleichsmatrix", "analysier das Paper", "was macht das Paper anders", "wo ist die Lücke". Auch triggern wenn der User einfach ein akademisches PDF hochlädt ohne explizite Anweisung — dann proaktiv fragen ob ein Related-Work-Vergleich gewünscht ist.
---

# Related-Work-Comparator für Demir (2026) Masterarbeit

## Zweck
Dieser Skill automatisiert den systematischen Vergleich von Forschungsarbeiten (Papers) gegen Mustafa Demirs Masterarbeit. Er produziert konsistente, wissenschaftlich fundierte Analysen mit einer standardisierten Vergleichsmatrix als Excel-Output.

## Wann verwenden
- User lädt ein PDF / Paper hoch und will wissen wie relevant es ist
- User will Related-Work-Abschnitt für Kapitel 2 aufbauen
- User will Abgrenzungssätze formulieren
- User will Feature-Matrix aktualisieren / erweitern
- User fragt nach Forschungslücken eines Papers

---

## PHASE 1: Paper-Intake & Qualitätsbewertung

### Schritt 1.1 — Metadaten extrahieren
Extrahiere aus dem Paper (egal ob PDF, Text, oder DOI-Lookup):

```
PAPER-STECKBRIEF:
- Titel:
- Autor(en):
- Jahr:
- Venue: (Journal/Konferenz/Preprint)
- DOI:
- Peer-Reviewed: Ja/Nein
- Affiliationen: (Uni, Forschungsinstitut, Industrie)
- Seitenzahl:
- Anzahl Referenzen:
```

### Schritt 1.2 — Akademische Qualitätsbewertung
Bewerte das Paper auf einer Ampel-Skala:

| Kriterium | 🟢 Stark | 🟡 Akzeptabel | 🔴 Schwach |
|-----------|----------|---------------|------------|
| Venue | Top-Tier Journal (IEEE Trans., ACM) | Workshop / Konferenz | Preprint ohne Review |
| Affiliation | Uni + Forschungsinstitut | Nur Uni oder nur Industrie | "Independent Researcher" |
| Methodik | Explizite Forschungsmethodik (DSR, SLR, Case Study) | Implizite Methodik | Keine erkennbare Methodik |
| Evaluation | Reale Implementierung / Experiment | Synthetische Daten / Simulation | Keine Evaluation |
| Referenzen | 30+ saubere Refs | 15-30 Refs | <15 oder fragwürdige Refs |
| Reproduzierbarkeit | Code/Daten verfügbar | Teilweise beschrieben | Nicht reproduzierbar |

**RED FLAGS prüfen:**
- Erfundene/fragwürdige DOIs in den Referenzen
- Predatory Journals (UGC CARE, MDPI Warnung)
- Übertriebene Claims ohne Evidenz ("reduces incidents by 60%" ohne Statistik)
- Single Author + "Independent Researcher" + kein Peer-Review

**Output:** Qualitäts-Urteil mit Empfehlung:
- 🟢 "Hauptquelle für Related Work" → In Vergleichstabelle aufnehmen
- 🟡 "Ergänzende Quelle" → In Kap. 2 Background, max. 1-2 Sätze
- 🔴 "Nicht verwenden" → Maximal als Fußnote mit Vorbehalt, oder ganz weglassen

### Schritt 1.3 — Kernbeiträge & Selbst-identifizierte Lücken extrahieren
Suche im Paper explizit nach:
- **Contributions-Abschnitt** (meist in Intro oder Conclusion)
- **Limitations / Future Work** (Gold für Abgrenzung!)
- **Explicit Gaps**: Sätze wie "we do not address...", "future research should...", "beyond the scope of..."
- **Implicit Gaps**: Was fehlt, obwohl es für Enterprise GenAI relevant wäre?

---

## PHASE 2: Systematischer Vergleich gegen Demir (2026)

### Demir-Referenzprofil (fest kodiert)
Dies ist das Profil der eigenen Arbeit, gegen das JEDES Paper verglichen wird:

```yaml
thesis:
  titel: "Enterprise-Referenzarchitektur für GenAI-Systeme mit Quality Gates und EU AI Act Compliance"
  methodik: "Design Science Research (Hevner et al.)"
  evaluation: "4-stufig: Requirements Coverage + Szenario-Walkthrough + PoC + Experteninterviews"
  use_case: "Ambient AI Scribe (Enterprise GenAI)"

architektur:
  typ: "Enterprise-Referenzarchitektur (GenAIOps)"
  4_saeulen:
    S1: "Architekturentwurf (Lifecycle-Phasen)"
    S2: "Quality-Gate-Framework (USP)"
    S3: "Pipeline-Integration (CI/CD/CT)"
    S4: "Compliance-Operationalisierung (USP)"

quality_gates:
  struktur: "Trigger → Kriterien → Evidenz → Entscheidung → Owner → Audit Trail → Waiver"
  dimensionen: "3D: Strategisch + Technisch + Compliance"
  automatisierung: "OPA/Rego Policies in CI/CD Pipeline"
  evidence_store: "Strukturierter Audit-Trail für Conformity Assessment"

compliance:
  eu_ai_act: "Kernfokus (Art. 9, 10, 13, 14, 15, 17)"
  compliance_as_code: "OPA/Rego Policies aligned mit AI Act Artikeln"
  conformity_assessment: "Evidence Store für Annex VI/VII"

pipeline:
  ci_cd: "GitHub Actions + ArgoCD + GitOps"
  ct: "Continuous Training bei Drift"
  policy_engine: "OPA / Rego"
  model_registry: "MLflow + Sigstore (SLSA Supply Chain)"
  evaluation: "DeepEval (Faithfulness, Hallucination, Toxicity)"
  container: "Kubernetes"

genai_spezifika:
  fokus: "GenAI / LLM (Enterprise)"
  rag: "Ja (Ambient AI Scribe Use Case)"
  hallucination_detection: "DeepEval als Gate-Kriterium"
  faithfulness: "DeepEval als Gate-Kriterium"
  drift_detection: "Automatisiert in CT-Pipeline"
  supply_chain: "Sigstore + SLSA"

problemdefinitionen:
  PD1: "Fragmentierung bestehender GenAIOps-Frameworks"
  PD2: "Fehlende formale Quality-Gate-Definitionen für GenAI-Systeme"
  PD3: "Lücken in der Operationalisierung von EU AI Act Compliance"
```

### Schritt 2.1 — Dimensionsvergleich durchführen
Vergleiche das Paper systematisch entlang dieser 7 Kategorien mit je 3-7 Dimensionen:

**Kategorie 1: PUBLIKATION & METHODIK**
- Publikationstyp, Peer-Review, Forschungsmethodik, Evaluation, Use Case

**Kategorie 2: ARCHITEKTUR-SCOPE**
- Architektur-Typ, Domänen-Fokus, Lifecycle-Abdeckung, Automatisierungsgrad

**Kategorie 3: QUALITY GATES (USP DEMIR)**
- Formalisierte Quality Gates, Gate-Dimensionen, Gate-Automatisierung, Waiver-Mechanismus, Evidence-Generierung

**Kategorie 4: COMPLIANCE & REGULATORIK**
- EU AI Act, Compliance-as-Code, Conformity Assessment, Risk Classification, Post-Market Monitoring

**Kategorie 5: PIPELINE & TOOLING**
- CI/CD Pipeline, Continuous Training, Policy Engine, Model Registry + Signatur, Evidence Store, Evaluation Framework, Container-Orchestrierung

**Kategorie 6: GenAI-SPEZIFIKA**
- GenAI/LLM Fokus, RAG-Pipeline, Prompt Engineering, Hallucination Detection, Faithfulness/Toxicity, Model Strategies, Drift Detection

**Kategorie 7: GOVERNANCE-STRUKTUR**
- Governance-Ebenen, Human-in-the-Loop, Audit-Trail, Stakeholder-Rollen

### Schritt 2.2 — Bewertungsskala pro Dimension
Jede Dimension bekommt eine der drei Bewertungen:

- **✓** = Vollständig adressiert (Paper behandelt dies explizit und substantiell)
- **◐** = Teilweise/konzeptionell adressiert (erwähnt, aber nicht ausgearbeitet)
- **✗** = Nicht adressiert

Bei ✓ und ◐: Immer eine kurze Beschreibung WIE das Paper es adressiert (max. 15 Wörter).

### Schritt 2.3 — Fundamentalen Unterschied formulieren
Beantworte die Kernfrage in einem Satz:
> "[Paper] liefert [WAS/WIE/WANN], während Demir [den komplementären Aspekt] adressiert."

Typische Muster:
- Paper = WAS (Komponenten), Demir = WIE (Betriebslogik, Automatisierung)
- Paper = manuell, Demir = automatisiert (Policy-as-Code)
- Paper = Cloud-Infra, Demir = GenAI-spezifisch
- Paper = Compliance-Mapping, Demir = Compliance-Automatisierung

---

## PHASE 3: Output-Generierung

### Schritt 3.1 — Textuelle Zusammenfassung (L1-Format)
Erstelle eine Bullet-Point-Zusammenfassung im Thesis-Arbeitsformat:

```
## [Paper-Kurztitel] — Relevanz für Demir (2026)

**Qualität:** 🟢/🟡/🔴 [Begründung in 1 Satz]
**Relevanz:** HOCH / MITTEL / NIEDRIG
**Empfohlene Platzierung:** Related Work Tabelle / Kap. 2 Background / Fußnote / Nicht verwenden

**Fundamentaler Unterschied:**
> [1 Satz]

**Was das Paper GUT macht (fair anerkennen):**
- [3-5 Bullets]

**Was das Paper NICHT hat (= Demir USP):**
- [3-5 Bullets, mapped auf PD1/PD2/PD3]

**Selbst-identifizierte Lücken (zitierfähig):**
- [Direkte Zitate aus Limitations/Future Work]

**Zitierfähiger Abgrenzungssatz für Kap. 2:**
> [1 Absatz, akademisch, APA-kompatibel]

**Elevator Pitch für Prof (max. 30 Sekunden):**
> [Gesprochener Text]

**Kritische Fragen:**
1. [Max. 3 Fragen zur weiteren Vertiefung]
```

### Schritt 3.2 — Excel-Matrix generieren/aktualisieren
Wenn der User eine Vergleichsmatrix will oder bereits eine existiert:

1. Lies die SKILL-Referenzdatei `references/matrix_template.py` für das Python-Script
2. Füge das neue Paper als zusätzliche Spalte hinzu
3. Verwende dasselbe Farbschema: ✓ grün / ◐ gelb / ✗ rot
4. Aktualisiere Sheet "Abgrenzungssätze" mit neuem Paper
5. Aktualisiere Sheet "Lücken-Analyse" 

**Excel-Output-Pfad:** `/mnt/user-data/outputs/Related_Work_Vergleichsmatrix.xlsx`

### Schritt 3.3 — Zotero-Empfehlung
Gib dem User die DOI und sage explizit:
> "DOI für Zotero-Import: [DOI]. Importiere über Zauberstab → DOI einfügen."

---

## PHASE 4: Einordnung in Thesis-Struktur

### Wo gehört das Paper hin?
Empfehle basierend auf Relevanz:

| Relevanz | Platzierung | Was schreiben |
|----------|-------------|---------------|
| HOCH | Kap. 2.x Related Work + Vergleichstabelle | Voller Vergleichsabsatz + Tabelleneintrag |
| MITTEL | Kap. 2.x Background | 1-2 Sätze als Kontextualisierung |
| NIEDRIG | Fußnote oder weglassen | Max. 1 Satz: "In verwandten Domänen..." |

### Stärkt es die Argumentation?
Prüfe explizit:
- Bestätigt das Paper eine der 3 Problemdefinitionen (PD1/PD2/PD3)?
- Gibt es selbst-identifizierte Lücken die Demirs USP stärken?
- Gibt es Konzepte die Demir übernehmen/referenzieren kann?

---

## WICHTIGE REGELN

1. **Keine erfundenen Quellen/DOIs** — Wenn DOI unbekannt, sage es
2. **Fair bleiben** — Stärken des Papers immer anerkennen
3. **APA7-kompatibel** — Alle Abgrenzungssätze in APA-Stil
4. **Scope-Drift verhindern** — Nur Dimensionen bewerten die für Demirs Thesis relevant sind
5. **Terminologie konsistent** — Verwende immer dieselben Begriffe wie in Demirs Exposé
6. **Unsicherheit markieren** — Wenn etwas unklar ist: "Hypothese:" voranstellen
7. **Kein Thesis-Fließtext** — Nur Analysen und Bullets, kein ausformulierter Text (es sei denn User sagt "GO" oder "FINAL")
8. **Output-Level L1** als Default: 10-15 Bullets + max. 3 kritische Fragen
