# Methodik-Dokumentation: Related-Work-Vergleichsmatrix

## Wie die Matrix entsteht — Schritt für Schritt

### INPUT (Was wird benötigt?)

```
┌─────────────────────────────────────────────────────┐
│ PFLICHT-INPUT:                                       │
│  • Volltext des Papers (PDF, eingefügter Text, URL) │
│  • Oder: DOI → dann Web-Search für Metadaten        │
│                                                      │
│ KONTEXT (aus Memory/Conversation):                   │
│  • Demirs Thesis-Profil (fest im Skill kodiert)     │
│  • Bisherige Related-Work-Papers (falls vorhanden)  │
│  • Aktuelle Problemdefinitionen PD1/PD2/PD3         │
└─────────────────────────────────────────────────────┘
```

### PROZESS (Was wird analysiert?)

```
PHASE 1: INTAKE                    PHASE 2: VERGLEICH
┌──────────────┐                   ┌──────────────────┐
│ Paper lesen  │                   │ 7 Kategorien ×   │
│ Metadaten    │──────────────────▶│ 3-7 Dimensionen  │
│ extrahieren  │                   │ = ~35 Vergleichs-│
│ Qualität     │                   │ punkte           │
│ bewerten     │                   └────────┬─────────┘
│ Lücken       │                            │
│ finden       │                            ▼
└──────────────┘                   ┌──────────────────┐
                                   │ Pro Dimension:   │
                                   │ ✓ / ◐ / ✗       │
                                   │ + Kurzbeschreib. │
                                   └────────┬─────────┘
                                            │
PHASE 3: OUTPUT                             │
┌──────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────┐
│ 1. Textuelle Zusammenfassung (L1)       │
│ 2. Excel-Matrix (3 Sheets)              │
│ 3. Zitierfähige Abgrenzungssätze        │
│ 4. Lücken-Analyse (PD1/PD2/PD3)        │
│ 5. Elevator Pitch für Prof              │
│ 6. Zotero-DOI                           │
└─────────────────────────────────────────┘
```

### DIE 7 VERGLEICHSKATEGORIEN (Detail)

```
Kategorie                  Warum?                           Typische Dimensionen
─────────────────────────────────────────────────────────────────────────────────
1. PUBLIKATION & METHODIK  Akademische Glaubwürdigkeit      Venue, Peer-Review, DSR?,
                           prüfen                           Evaluation, Use Case

2. ARCHITEKTUR-SCOPE       Wie umfassend ist der Ansatz?    Typ, Domäne, Lifecycle,
                                                            Automatisierungsgrad

3. QUALITY GATES           Demirs Kern-USP — hier muss      Formalisierung, Dimensionen,
   (USP DEMIR)             die Abgrenzung sitzen            Automatisierung, Waiver,
                                                            Evidence-Generierung

4. COMPLIANCE &            Zweiter USP — EU AI Act          AI Act, Compliance-as-Code,
   REGULATORIK             Operationalisierung              Conformity, Risk Class., PMM

5. PIPELINE & TOOLING      Technische Implementierung       CI/CD, CT, Policy Engine,
                                                            Registry, Evidence Store,
                                                            DeepEval, K8s

6. GenAI-SPEZIFIKA         Domänen-Abgrenzung               LLM-Fokus, RAG, Prompt Eng.,
                                                            Hallucination, Faithfulness,
                                                            Model Strategies, Drift

7. GOVERNANCE-STRUKTUR     Organisatorischer Rahmen         Governance-Ebenen, HitL,
                                                            Audit-Trail, Rollen
```

### BEWERTUNGSLOGIK

```
Entscheidungsbaum pro Dimension:

    Paper behandelt diese Dimension?
    ├── NEIN → ✗ (rot)
    └── JA
        ├── Explizit + substantiell ausgearbeitet?
        │   └── JA → ✓ (grün) + Kurzbeschreibung WIE
        └── Nur erwähnt / konzeptionell / oberflächlich?
            └── ◐ (gelb) + Kurzbeschreibung WAS erwähnt wird
```

### OUTPUT (Was wird produziert?)

```
┌─────────────────────────────────────────────────────┐
│ EXCEL-DATEI: Related_Work_Vergleichsmatrix.xlsx     │
│                                                      │
│ Sheet 1: Feature-Matrix                              │
│   • Zeilen: 35+ Dimensionen in 7 Kategorien         │
│   • Spalten: Demir + n Papers                        │
│   • Farbkodiert: ✓ grün / ◐ gelb / ✗ rot           │
│   • Demir-Spalte blau hervorgehoben                  │
│                                                      │
│ Sheet 2: Abgrenzungssätze                            │
│   • Pro Paper: 1 zitierfähiger Absatz (APA7)        │
│   • Synthese-Absatz für eigenen Beitrag              │
│   • DOIs für Zotero-Import                           │
│                                                      │
│ Sheet 3: Lücken-Analyse                              │
│   • Zeilen: PD1 + PD2 + PD3 + weitere Lücken       │
│   • Spalten: Papers + Demir-Lösung                   │
│   • Zeigt: Nur Demir schließt ALLE Lücken            │
└─────────────────────────────────────────────────────┘
```

### QUALITÄTSKRITERIEN FÜR DIE ANALYSE

1. **Fairness**: Stärken des Papers IMMER anerkennen
2. **Traceability**: Jede Bewertung muss auf konkreter Textstelle basieren
3. **Konsistenz**: Dieselben Dimensionen für ALLE Papers
4. **Scope**: Nur Dimensionen die für Demirs Thesis relevant sind
5. **Keine Erfindungen**: Keine DOIs, Zitate oder Seitenzahlen erfinden
6. **Unsicherheit**: Wenn unklar → "Hypothese:" markieren
